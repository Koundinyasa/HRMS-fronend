import { baseApi } from "@/app/baseApi";
import type {
  PendingLeaveRequestParams,
  PendingLeaveRequestsResponse,
} from "../types/requisition.types";

export const requisitionApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    getPendingLeaveRequests: builder.mutation<
      PendingLeaveRequestsResponse,
      PendingLeaveRequestParams
    >({
      query: () => ({
        url: "/employee/leave/pending",
        method: "GET",
      }),
    }),

    approveLeaveRequests: builder.mutation<
      unknown,
      { approvalId: number; actionStatusId: number; remarks?: string }
    >({
      query: (body) => ({
        url: "/employee/leave/approval",
        method: "POST",
        body,
      }),
    }),

    rejectLeaveRequests: builder.mutation<
      unknown,
      { approvalId: number; actionStatusId: number; remarks?: string }
    >({
      query: (body) => ({
        url: "/employee/leave/approval",
        method: "POST",
        body,
      }),
    }),
  }),
});

export const {
  useGetPendingLeaveRequestsMutation,
  useApproveLeaveRequestsMutation,
  useRejectLeaveRequestsMutation,
} = requisitionApi;