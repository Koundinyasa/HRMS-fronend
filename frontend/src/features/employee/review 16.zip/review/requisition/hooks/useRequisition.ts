import {
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  useGetPendingLeaveRequestsMutation,
  useApproveLeaveRequestsMutation,
  useRejectLeaveRequestsMutation,
} from "../api/requisitionApi";

import {
  REQUISITION_MESSAGES,
} from "../constants/requisition.constants";

import type {
  PendingLeaveRequest,
  Requisition,
} from "../types/requisition.types";

const extractRequests = (
  response: unknown
): PendingLeaveRequest[] => {
  if (Array.isArray(response)) {
    return response as PendingLeaveRequest[];
  }

  if (response && typeof response === "object") {
    const result = response as Record<string, unknown>;

    const possibleKeys = [
      "data",
      "result",
      "items",
      "records",
      "requests",
    ];

    for (const key of possibleKeys) {
      const value = result[key];

      if (Array.isArray(value)) {
        return value as PendingLeaveRequest[];
      }

      if (value && typeof value === "object") {
        const nested = extractRequests(value);

        if (nested.length > 0) {
          return nested;
        }
      }
    }
  }

  return [];
};

const normalizeNumericValue = (...values: Array<string | number | null | undefined>) => {
  for (const value of values) {
    if (value === null || value === undefined || value === "") {
      continue;
    }

    const normalized = Number(value);

    if (Number.isFinite(normalized) && normalized > 0) {
      return normalized;
    }
  }

  return 0;
};

const resolveIdFromRecord = (item: PendingLeaveRequest) => {
  return normalizeNumericValue(
    item.ApprovalId,
    item.ApprovalID,
    item.approvalId,
    item.approval_id,
    item.LeaveApplicationId,
    item.leaveApplicationId,
    item.LeaveId,
    item.LeaveID,
    item.leaveId,
    item.leave_id,
    item.RequestId,
    item.requestId,
    item.Id,
    item.id,
  );
};

const mapRequest = (
  item: PendingLeaveRequest,
  index: number
): Requisition => {
  const possibleApprovalId = resolveIdFromRecord(item);

  const possibleLeaveApplicationId = normalizeNumericValue(
    item.LeaveApplicationId,
    item.leaveApplicationId
  );

  const possibleLeaveId = normalizeNumericValue(
    item.LeaveId,
    item.LeaveID,
    item.leaveId,
    item.leave_id,
    item.Id,
    item.id,
    item.RequestId,
    item.requestId
  );

  const primaryRecordId =
    possibleLeaveApplicationId > 0
      ? possibleLeaveApplicationId
      : possibleLeaveId > 0
        ? possibleLeaveId
        : 0;

  const effectiveApprovalId = possibleApprovalId;

  return {
    id: String(
      primaryRecordId ||
        `${item.EmployeeId ?? item.employeeId ?? "employee"}-${item.FromDate ?? item.fromDate ?? item.AppliedDate ?? index}-${index}`
    ),
    approvalId: effectiveApprovalId,
    leaveId: possibleLeaveId,
    leaveApplicationId: possibleLeaveApplicationId > 0 ? possibleLeaveApplicationId : undefined,
    employeeId: String(item.EmployeeId ?? item.employeeId ?? ""),
    employeeName: String(item.EmployeeName ?? item.employeeName ?? ""),
    leaveName: String(item.LeaveName ?? item.leaveName ?? ""),
    date: String(item.FromDate ?? item.fromDate ?? item.AppliedDate ?? ""),
    days: Number(item.NoDays ?? item.NoOfDays ?? item.noDays ?? item.days ?? 0),
    reason: String(item.Reason ?? item.reason ?? ""),
  };
};

export const useRequisition = () => {
  const [
    getPendingLeaveRequests,
    { data, isLoading, isError },
  ] = useGetPendingLeaveRequestsMutation();

  const [approveLeaveRequests] = useApproveLeaveRequestsMutation();
  const [rejectLeaveRequests] = useRejectLeaveRequestsMutation();

  const [search, setSearch] = useState("");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const fetchParams = {
    fromDate: "2026-08-01",
    toDate: "2026-09-30",
  };

  const refetch = () => getPendingLeaveRequests(fetchParams);

  useEffect(() => {
    void refetch();
  }, [getPendingLeaveRequests]);

  console.log("RAW API DATA:", data);
  const requisitions: Requisition[] = useMemo(
    () => extractRequests(data).map(mapRequest),
    [data]
  );

  const filteredRequisitions = useMemo(() => {
    const value = search.trim().toLowerCase();

    if (!value) return requisitions;

    return requisitions.filter((item) =>
      [
        item.id,
        item.employeeId,
        item.employeeName,
        item.leaveName,
        item.date,
        item.days,
        item.reason,
      ].some((field) =>
        String(field ?? "")
          .toLowerCase()
          .includes(value)
      )
    );
  }, [requisitions, search]);

  const toggleSelect = (id: string) => {
    setSelectedIds((previous) =>
      previous.includes(id)
        ? previous.filter((selectedId) => selectedId !== id)
        : [...previous, id]
    );
  };

  const toggleSelectAll = () => {
    const visibleIds = filteredRequisitions.map((item) => item.id);

    const allSelected =
      visibleIds.length > 0 &&
      visibleIds.every((id) => selectedIds.includes(id));

    setSelectedIds((previous) =>
      allSelected
        ? previous.filter((id) => !visibleIds.includes(id))
        : Array.from(new Set([...previous, ...visibleIds]))
    );
  };

const updateSelected = async (
  action: "approved" | "rejected"
): Promise<Requisition[]> => {
  const selectedRequests = requisitions.filter((item) =>
    selectedIds.includes(item.id)
  );

  console.log("selectedRequests before approval", selectedRequests);

  const requestsToSubmit = selectedRequests
    .map((item) => ({ ...item }))
    .filter((item) => item.approvalId > 0);

  console.log("requestsToSubmit before approval", requestsToSubmit);

  if (requestsToSubmit.length === 0) {
    console.warn("No valid approvalId found. Full selected data:", selectedRequests);
    return [];
  }

  const mutation =
    action === "approved" ? approveLeaveRequests : rejectLeaveRequests;

  for (const item of requestsToSubmit) {
    await mutation({
      approvalId: item.approvalId,
      actionStatusId: action === "approved" ? 4 : 5,
    }).unwrap();
  }

  setSelectedIds([]);
  try {
    await refetch().unwrap();
  } catch (error) {
    console.warn("Approval succeeded, but leave requests could not refresh.", error);
  }

  return selectedRequests;
};

  return {
    requisitions: filteredRequisitions,
    search,
    setSearch,
    selectedIds,
    toggleSelect,
    toggleSelectAll,
    updateSelected,
    loading: isLoading,
    error: isError ? REQUISITION_MESSAGES.FETCH_ERROR : "",
    refetch,
  };
};