import { useState } from "react";

import RequisitionNavbar from "../components/RequisitionNavbar";
import RequisitionToolbar from "../components/RequisitionToolbar";
import RequisitionTable from "../components/RequisitionTable";
import RequisitionRemarksPage from "../components/RequisitionRemarksPage";
import type { Requisition } from "../types/requisition.types";

import { useRequisition } from "../hooks/useRequisition";

function getRequestErrorMessage(error: unknown, fallback: string) {
  if (error && typeof error === "object") {
    const data = (error as { data?: unknown }).data;

    if (data && typeof data === "object" && "message" in data) {
      const message = (data as { message?: unknown }).message;
      if (typeof message === "string") return message;
    }

    if ("error" in error) {
      const message = (error as { error?: unknown }).error;
      if (typeof message === "string") return message;
    }
  }

  return fallback;
}

export default function RequisitionPage() {
  const {
    requisitions,
    search,
    setSearch,
    selectedIds,
    toggleSelect,
    toggleSelectAll,
    updateSelected,
    loading,
    error,
  } = useRequisition();

  const [showHistory, setShowHistory] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [rejectedRequests, setRejectedRequests] = useState<Requisition[]>([]);

  const handleApprove = async () => {
    if (selectedIds.length === 0) return;

    try {
      const approvedRequests = await updateSelected("approved");

      if (approvedRequests.length > 0) {
        setSuccessMessage("REQUEST IS APPROVED SUCCESSFULLY");
        setRejectedRequests([]);
      } else {
        setSuccessMessage("No valid requests selected for approval.");
        setTimeout(() => setSuccessMessage(""), 3000);
      }
    } catch (err) {
      console.error("Approve failed:", err);
      setSuccessMessage(
        getRequestErrorMessage(
          err,
          "Failed to approve the request. Please try again."
        )
      );
      setTimeout(() => setSuccessMessage(""), 4000);
    }
  };

  const handleReject = async () => {
    const rejected = requisitions.filter((item) =>
      selectedIds.includes(item.id)
    );

    if (rejected.length === 0) return;

    setRejectedRequests(rejected);
    setSuccessMessage("");

    try {
      await updateSelected("rejected");
    } catch (actionError) {
      console.error("Unable to reject leave requests.", actionError);
      setSuccessMessage(
        getRequestErrorMessage(actionError, "Failed to reject the request.")
      );
      setTimeout(() => setSuccessMessage(""), 4000);
    }
  };

  return (
    <div className="min-h-screen bg-[#f3f4f9] p-4 sm:p-5 md:p-[26px]">
      <div className="mx-auto w-full space-y-3">
        <RequisitionNavbar />

        <RequisitionToolbar
          search={search}
          onSearchChange={setSearch}
          onApprove={() => void handleApprove()}
          onReject={() => void handleReject()}
          onHistory={() => setShowHistory((prev) => !prev)}
          hasSelection={selectedIds.length > 0}
          approved={!!successMessage && successMessage.includes("APPROVED")}
        />

        {error && (
          <div
            role="alert"
            className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-600"
          >
            {error}
          </div>
        )}

        {successMessage && (
          <div
            role="status"
            className={`rounded-md border p-4 text-sm font-medium ${
              successMessage.includes("APPROVED")
                ? "border-green-200 bg-green-50 text-green-700"
                : successMessage.includes("Failed")
                ? "border-red-200 bg-red-50 text-red-700"
                : "border-yellow-200 bg-yellow-50 text-yellow-700"
            }`}
          >
            {successMessage}
          </div>
        )}

        {loading && (
          <div className="rounded-md bg-white p-5 text-center text-sm text-slate-500">
            Loading leave requisitions...
          </div>
        )}

        {showHistory && (
          <div className="rounded-md border border-slate-200 bg-white p-4 text-sm text-slate-600">
            Leave history
            <button
              type="button"
              onClick={() => setShowHistory(false)}
              className="ml-3 text-sky-600"
            >
              Close
            </button>
          </div>
        )}

        {!loading && rejectedRequests.length > 0 && (
          <RequisitionRemarksPage
            requisitions={rejectedRequests}
            onBack={() => setRejectedRequests([])}
          />
        )}

        {!loading && rejectedRequests.length === 0 && (
          <RequisitionTable
            requisitions={requisitions}
            selectedIds={selectedIds}
            onSelectAll={toggleSelectAll}
            onSelect={toggleSelect}
          />
        )}
      </div>
    </div>
  );
}