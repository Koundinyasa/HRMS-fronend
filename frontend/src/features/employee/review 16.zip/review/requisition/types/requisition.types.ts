/** Request parameters sent to the pending leave requests API. */
export interface PendingLeaveRequestParams {
  fromDate: string;
  toDate: string;
}

export interface PendingLeaveRequest {
  ApprovalId?: string | number;
  ApprovalID?: string | number;
  approvalId?: string | number;
  approval_id?: string | number;
  approvalID?: string | number;
  LeaveId?: string | number;
  LeaveID?: string | number;
  leaveId?: string | number;
  leave_id?: string | number;
  LeaveApplicationId?: string | number;
  leaveApplicationId?: string | number;
  Id?: string | number;
  id?: string | number;
  RequestId?: string | number;
  requestId?: string | number;
  EmployeeId?: string | number;
  employeeId?: string | number;
  EmployeeName?: string;
  employeeName?: string;
  LeaveName?: string;
  leaveName?: string;
  FromDate?: string;
  fromDate?: string;
  ToDate?: string;
  AppliedDate?: string;
  NoDays?: number | string;
  NoOfDays?: number | string;
  noDays?: number | string;
  days?: number | string;
  Reason?: string | null;
  reason?: string | null;
  [key: string]: any;
}
/** Fields used by the requisition UI. */

export interface Requisition {
  id: string;
  approvalId: number;
  leaveId: number;
  leaveApplicationId?: number;
  employeeId: string;
  employeeName: string;
  leaveName: string;
  date: string;
  days: number;
  reason: string;
}




/** Props for the requisition table. */
export interface RequisitionTableProps {
  requisitions: Requisition[];
  selectedIds: string[];
  onSelectAll: () => void;
  onSelect: (id: string) => void;
}

/** Props for the requisition toolbar. */
export interface RequisitionToolbarProps {
  search: string;
  onSearchChange: (value: string) => void;
  onApprove: () => void;
  onReject: () => void;
  onHistory: () => void;
  hasSelection: boolean;
  approved?: boolean;
}

/** Result returned by requisition date validation. */
export interface RequisitionValidationResult {
  isValid: boolean;
  message: string;
}

export type PendingLeaveRequestsResponse = PendingLeaveRequest[];