// import {
//   useCallback,
//   useEffect,
//   useMemo,
//   useState,
// } from "react";

// import { useAttendance } from "./useRegularization";
// import { useGetReportingEmployeesQuery } from "../api/regularizationApi";

// import type {
//   AttendanceView,
//   OverviewDetailKey,
//   PunchTab,
//   Toast,
// } from "../types/attendanceOverview.types";

// import type { Employee } from "../types/regularization.types";

// import {
//   getOverviewStats,
//   normalizeAttendanceRows,
// } from "../validations/regularization.validations";

// export function useAttendanceOverview() {
//   // =====================================================
//   // REPORTING EMPLOYEES
//   // =====================================================

//   const {
//     data: reportingEmployees = [],
//     isLoading: reportingEmployeesLoading,
//     error: reportingEmployeesError,
//   } = useGetReportingEmployeesQuery();

//   const employeeOptions = useMemo<Employee[]>(
//     () =>
//       reportingEmployees.map((employee) => ({
//         id: employee.EmployeeID,
//         name: employee.EmployeeName,
//       })),
//     [reportingEmployees],
//   );

//   // =====================================================
//   // SELECTED EMPLOYEE
//   // =====================================================

//   const [selectedEmployee, setSelectedEmployee] =
//     useState<Employee | null>(null);

//   useEffect(() => {
//     if (
//       employeeOptions.length > 0 &&
//       !selectedEmployee
//     ) {
//       setSelectedEmployee(employeeOptions[0]);
//     }
//   }, [employeeOptions, selectedEmployee]);

//   // =====================================================
//   // ATTENDANCE VIEW
//   // =====================================================

//   const [view, setView] =
//     useState<AttendanceView>("list");

//   // =====================================================
//   // SELECTED MONTH
//   // =====================================================

//   const currentDate = useMemo(
//     () => new Date(),
//     [],
//   );

//   const currentMonth = currentDate.toLocaleString(
//     "en-US",
//     {
//       month: "short",
//     },
//   );

//   const currentYear =
//     currentDate.getFullYear();

//   const [selectedMonth, setSelectedMonth] =
//     useState(
//       `${currentMonth}/${currentYear}`,
//     );

//   // =====================================================
//   // ATTENDANCE FILTER VALUES
//   // =====================================================

//   const [assignedShift, setAssignedShift] =
//     useState("");

//   const [workedShift, setWorkedShift] =
//     useState("");

//   const [assignedPolicy, setAssignedPolicy] =
//     useState("");

//   const [assignedPattern, setAssignedPattern] =
//     useState("");

//   // =====================================================
//   // SELECTED DATE
//   // =====================================================

//   const [selectedDate, setSelectedDate] =
//     useState(
//       currentDate.getDate(),
//     );

//   // =====================================================
//   // PUNCH TAB
//   // =====================================================

//   const [punchTab, setPunchTab] =
//     useState<PunchTab>("raw");

//   // =====================================================
//   // TOASTS
//   // =====================================================

//   const [toasts, setToasts] =
//     useState<Toast[]>([]);

//   // =====================================================
//   // PROCESSING STATE
//   // =====================================================
//   // These are currently local UI states.
//   // They should be connected to an API when the
//   // attendance processing API is available.

//   const [processed, setProcessed] =
//     useState(false);

//   const [processedAt, setProcessedAt] =
//     useState<string | null>(null);

//   const [processMenuOpen, setProcessMenuOpen] =
//     useState(false);

//   // =====================================================
//   // OVERVIEW DETAIL MODAL
//   // =====================================================

//   const [activeDetailModal, setActiveDetailModal] =
//     useState<OverviewDetailKey | null>(null);

//   // =====================================================
//   // MONTH / YEAR
//   // =====================================================

//   const [monthLabel, monthYear] =
//     selectedMonth.split("/");

//   const selectedMonthNumber = useMemo(() => {
//     const date = new Date(
//       `${monthLabel} 1, ${monthYear}`,
//     );

//     const month = date.getMonth() + 1;

//     return Number.isInteger(month) &&
//       month >= 1 &&
//       month <= 12
//       ? month
//       : currentDate.getMonth() + 1;
//   }, [
//     monthLabel,
//     monthYear,
//     currentDate,
//   ]);

//   const selectedYear =
//     Number(monthYear) ||
//     currentDate.getFullYear();

//   // =====================================================
//   // ATTENDANCE API
//   // =====================================================

//   const {
//     attendance,
//     overview,
//     punchRecords,
//     loading,
//     error,
//     loadPunchDetails,
//     loadRawPunches,
//   } = useAttendance({
//     employeeId:
//       selectedEmployee?.id ?? "",

//     month: selectedMonthNumber,

//     year: selectedYear,

//     /*
//      * classificationId must come from the employee/API data.
//      * It should NOT be hardcoded here.
//      *
//      * This will be connected after the reporting employee
//      * response/type exposes ClassificationId.
//      */
//     classificationId:
//       Number(
//         selectedEmployee?.classificationId,
//       ) || 0,
//   });

//   // =====================================================
//   // PUNCH RECORDS
//   // =====================================================

//   const rawPunches = useMemo(
//     () =>
//       punchRecords.map((punch) => ({
//         time:
//           punch.time ??
//           punch.punchTime ??
//           "",

//         type:
//           (punch.type ??
//             punch.punchType) as
//             | "In"
//             | "Out",

//         source:
//           punch.source ??
//           punch.punchSource ??
//           "",
//       })),
//     [punchRecords],
//   );

//   // =====================================================
//   // NORMALIZED ATTENDANCE
//   // =====================================================

//   const days = useMemo(
//     () =>
//       normalizeAttendanceRows(
//         attendance,
//         selectedYear,
//         selectedMonthNumber,
//       ),
//     [
//       attendance,
//       selectedYear,
//       selectedMonthNumber,
//     ],
//   );

//   // =====================================================
//   // OVERVIEW STATS
//   // =====================================================

//   const overviewStats = useMemo(
//     () =>
//       getOverviewStats(
//         overview,
//         days,
//       ),
//     [overview, days],
//   );

//   // =====================================================
//   // ACTIVE DAY
//   // =====================================================

//   const activeDay =
//     days.find(
//       (day) =>
//         day.date === selectedDate,
//     ) ?? days[0];

//   // =====================================================
//   // KEEP SELECTED DATE VALID
//   // =====================================================

//   useEffect(() => {
//     if (
//       days.length > 0 &&
//       !days.some(
//         (day) =>
//           day.date === selectedDate,
//       )
//     ) {
//       setSelectedDate(days[0].date);
//     }
//   }, [
//     days,
//     selectedDate,
//   ]);

//   // =====================================================
//   // TOAST
//   // =====================================================

//   const pushToast = useCallback(
//     (
//       message: string,
//       tone: Toast["tone"] = "info",
//     ) => {
//       const id =
//         Date.now() +
//         Math.random();

//       setToasts((current) => [
//         ...current,
//         {
//           id,
//           message,
//           tone,
//         },
//       ]);

//       window.setTimeout(() => {
//         setToasts((current) =>
//           current.filter(
//             (item) =>
//               item.id !== id,
//           ),
//         );
//       }, 3200);
//     },
//     [],
//   );

//   // =====================================================
//   // PROCESS ATTENDANCE
//   // =====================================================
//   // Temporary local UI behavior.
//   // Replace with API mutation once processing API is provided.

//   const handleProcessClick =
//     useCallback(() => {
//       if (!processed) {
//         setProcessed(true);

//         setProcessedAt(
//           new Date().toLocaleString(),
//         );

//         pushToast(
//           "Attendance processed successfully.",
//           "success",
//         );
//       } else {
//         setProcessMenuOpen(
//           (value) => !value,
//         );
//       }
//     }, [
//       processed,
//       pushToast,
//     ]);

//   // =====================================================
//   // REPROCESS
//   // =====================================================

//   const handleReprocess =
//     useCallback(() => {
//       setProcessedAt(
//         new Date().toLocaleString(),
//       );

//       setProcessMenuOpen(false);

//       pushToast(
//         "Attendance re-processed successfully.",
//         "success",
//       );
//     }, [pushToast]);

//   // =====================================================
//   // UNDO PROCESS
//   // =====================================================

//   const handleUndoProcess =
//     useCallback(() => {
//       setProcessed(false);
//       setProcessedAt(null);
//       setProcessMenuOpen(false);

//       pushToast(
//         "Attendance processing undone.",
//         "info",
//       );
//     }, [pushToast]);

//   // =====================================================
//   // EXPORT
//   // =====================================================

//   const handleExport =
//     useCallback(() => {
//       try {
//         const header =
//           "Date,Day,Shift,Status,Check In,Check Out,Gross Work Hours,Work Hours,Break Hours";

//         const rows = days.map(
//           (day) =>
//             [
//               day.date,
//               day.day,
//               day.shift,
//               day.status,
//               day.checkIn ?? "",
//               day.checkOut ?? "",
//               day.grossWorkHours ?? "",
//               day.workHours ?? "",
//               day.breakHours ?? "",
//             ].join(","),
//         );

//         const csv = [
//           header,
//           ...rows,
//         ].join("\n");

//         const blob =
//           new Blob([csv], {
//             type: "text/csv;charset=utf-8;",
//           });

//         const url =
//           URL.createObjectURL(
//             blob,
//           );

//         const anchor =
//           document.createElement(
//             "a",
//           );

//         anchor.href = url;

//         anchor.download =
//           `attendance_${
//             selectedEmployee?.id ?? ""
//           }_${selectedMonth.replace(
//             "/",
//             "-",
//           )}.csv`;

//         document.body.appendChild(
//           anchor,
//         );

//         anchor.click();

//         document.body.removeChild(
//           anchor,
//         );

//         window.setTimeout(() => {
//           URL.revokeObjectURL(
//             url,
//           );
//         }, 5000);

//         pushToast(
//           "Attendance exported successfully.",
//           "success",
//         );
//       } catch (exportError) {
//         console.error(
//           "CSV export failed:",
//           exportError,
//         );

//         pushToast(
//           "Export failed.",
//           "info",
//         );
//       }
//     }, [
//       days,
//       pushToast,
//       selectedEmployee?.id,
//       selectedMonth,
//     ]);

//   // =====================================================
//   // SELECT DATE
//   // =====================================================

//   const selectDate =
//     useCallback(
//       (date: number) => {
//         setSelectedDate(date);
//       },
//       [],
//     );

//   // =====================================================
//   // SELECT EMPLOYEE
//   // =====================================================

//   const selectEmployee =
//     useCallback(
//       (employee: Employee) => {
//         setSelectedEmployee(
//           employee,
//         );

//         setSelectedDate(
//           currentDate.getDate(),
//         );
//       },
//       [currentDate],
//     );

//   // =====================================================
//   // DETAIL MODAL
//   // =====================================================

//   const openDetailModal =
//     useCallback(
//       (key: OverviewDetailKey) => {
//         setActiveDetailModal(
//           key,
//         );
//       },
//       [],
//     );

//   const closeDetailModal =
//     useCallback(() => {
//       setActiveDetailModal(null);
//     }, []);

//   // =====================================================
//   // LOAD SELECTED DAY PUNCHES
//   // =====================================================

//   const loadSelectedDayPunches =
//     useCallback(
//       async () => {
//         if (!activeDay) {
//           return;
//         }

//         const date =
//           `${selectedYear}-${String(
//             selectedMonthNumber,
//           ).padStart(
//             2,
//             "0",
//           )}-${String(
//             activeDay.date,
//           ).padStart(
//             2,
//             "0",
//           )}`;

//         try {
//           await loadPunchDetails(
//             date,
//           );

//           await loadRawPunches(
//             date,
//           );
//         } catch (punchError) {
//           console.error(
//             "Failed to load punch details:",
//             punchError,
//           );
//         }
//       },
//       [
//         activeDay,
//         selectedYear,
//         selectedMonthNumber,
//         loadPunchDetails,
//         loadRawPunches,
//       ],
//     );

//   // =====================================================
//   // RETURN
//   // =====================================================

//   return {
//     view,
//     setView,

//     selectedMonth,
//     setSelectedMonth,

//     employees:
//       employeeOptions,

//     selectedEmployee,
//     selectEmployee,

//     reportingEmployeesLoading,
//     reportingEmployeesError,

//     selectedMonthNumber,
//     selectedYear,

//     assignedShift,
//     setAssignedShift,

//     workedShift,
//     setWorkedShift,

//     assignedPolicy,
//     setAssignedPolicy,

//     assignedPattern,
//     setAssignedPattern,

//     selectedDate,
//     setSelectedDate:
//       selectDate,

//     punchTab,
//     setPunchTab,

//     days,
//     activeDay,

//     overview,
//     overviewStats,

//     loading,
//     error,

//     toasts,
//     setToasts,
//     pushToast,

//     processed,
//     processedAt,

//     processMenuOpen,
//     setProcessMenuOpen,

//     activeDetailModal,
//     openDetailModal,
//     closeDetailModal,

//     handleProcessClick,
//     handleReprocess,
//     handleUndoProcess,
//     handleExport,

//     loadSelectedDayPunches,

//     rawPunches,
//   };
// }

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";

import { useAttendance } from "./useRegularization";
import { useGetAttendanceOverviewEmployeesQuery } from "../api/regularizationApi";

import type {
  AttendanceView,
  OverviewDetailKey,
  PunchTab,
  Toast,
} from "../types/attendanceOverview.types";

import type { Employee } from "../types/regularization.types";

import {
  getOverviewStats,
  normalizeAttendanceRows,
} from "../validations/regularization.validations";

export function useAttendanceOverview() {
  // =====================================================
  // REPORTING EMPLOYEES
  // =====================================================

  const {
    data: reportingEmployees = [],
    isLoading: reportingEmployeesLoading,
    error: reportingEmployeesError,
  } = useGetAttendanceOverviewEmployeesQuery();

  const employeeOptions = useMemo<Employee[]>(
    () =>
      reportingEmployees.map((employee) => {
        const rawClassId =
          employee.ClassificationId ?? employee.classificationId;
        const classificationId =
          rawClassId !== undefined && rawClassId !== null && rawClassId !== ""
            ? Number(rawClassId)
            : undefined;

        return {
          id: employee.EmployeeID,
          name: employee.EmployeeName,
          ...(Number.isFinite(classificationId) && classificationId! > 0
            ? { classificationId }
            : {}),
        };
      }),
    [reportingEmployees],
  );

  // =====================================================
  // SELECTED EMPLOYEE
  // =====================================================

  const [selectedEmployee, setSelectedEmployee] =
    useState<Employee | null>(null);

  useEffect(() => {
    if (
      employeeOptions.length > 0 &&
      !selectedEmployee
    ) {
      setSelectedEmployee(employeeOptions[0]);
    }
  }, [employeeOptions, selectedEmployee]);

  // =====================================================
  // ATTENDANCE VIEW
  // =====================================================

  const [view, setView] =
    useState<AttendanceView>("list");

  // =====================================================
  // SELECTED MONTH
  // =====================================================

  const currentDate = useMemo(
    () => new Date(),
    [],
  );

  const currentMonth = currentDate.toLocaleString(
    "en-US",
    {
      month: "short",
    },
  );

  const currentYear =
    currentDate.getFullYear();

  const [selectedMonth, setSelectedMonth] =
    useState(
      `${currentMonth}/${currentYear}`,
    );

  // =====================================================
  // ATTENDANCE FILTER VALUES
  // =====================================================

  const [assignedShift, setAssignedShift] =
    useState("");

  const [workedShift, setWorkedShift] =
    useState("");

  const [assignedPolicy, setAssignedPolicy] =
    useState("");

  const [assignedPattern, setAssignedPattern] =
    useState("");

  // =====================================================
  // SELECTED DATE
  // =====================================================

  const [selectedDate, setSelectedDate] =
    useState(
      currentDate.getDate(),
    );

  // =====================================================
  // PUNCH TAB
  // =====================================================

  const [punchTab, setPunchTab] =
    useState<PunchTab>("raw");

  // =====================================================
  // TOASTS
  // =====================================================

  const [toasts, setToasts] =
    useState<Toast[]>([]);

  // =====================================================
  // PROCESSING STATE
  // =====================================================
  // These are currently local UI states.
  // They should be connected to an API when the
  // attendance processing API is available.

  const [processed, setProcessed] =
    useState(false);

  const [processedAt, setProcessedAt] =
    useState<string | null>(null);

  const [processMenuOpen, setProcessMenuOpen] =
    useState(false);

  // =====================================================
  // OVERVIEW DETAIL MODAL
  // =====================================================

  const [activeDetailModal, setActiveDetailModal] =
    useState<OverviewDetailKey | null>(null);

  // =====================================================
  // MONTH / YEAR
  // =====================================================

  const [monthLabel, monthYear] =
    selectedMonth.split("/");

  const selectedMonthNumber = useMemo(() => {
    const date = new Date(
      `${monthLabel} 1, ${monthYear}`,
    );

    const month = date.getMonth() + 1;

    return Number.isInteger(month) &&
      month >= 1 &&
      month <= 12
      ? month
      : currentDate.getMonth() + 1;
  }, [
    monthLabel,
    monthYear,
    currentDate,
  ]);

  const selectedYear =
    Number(monthYear) ||
    currentDate.getFullYear();

  // =====================================================
  // ATTENDANCE API
  // =====================================================

  const {
    attendance,
    overview: rawOverview,
    punchRecords,
    loading,
    error,
    loadPunchDetails,
    loadRawPunches,
  } = useAttendance({
    employeeId:
      selectedEmployee?.id ?? "",

    month: selectedMonthNumber,

    year: selectedYear,

    /*
     * classificationId must come from the employee/API data.
     * Prefer the value from reporting-employees when present.
     * Fall back to 0 only so the request is still issued
     * (some backends accept 0 / ignore the field).
     */
    classificationId:
      Number(
        selectedEmployee?.classificationId,
      ) || 0,
  });

  // =====================================================
  // PUNCH RECORDS
  // =====================================================

    // =====================================================
  // PUNCH RECORDS
  // =====================================================

  const rawPunches = useMemo(
    () =>
      punchRecords.map((punch) => ({
        time: punch.time ?? "",
        type: (punch.type || "In") as "In" | "Out",
        source: punch.source ?? "",
      })),
    [punchRecords],
  );
  // =====================================================
  // NORMALIZED ATTENDANCE
  // =====================================================

  const days = useMemo(
    () =>
      normalizeAttendanceRows(
        attendance,
        selectedYear,
        selectedMonthNumber,
      ),
    [
      attendance,
      selectedYear,
      selectedMonthNumber,
    ],
  );

  // =====================================================
  // RESOLVE OVERVIEW TO THE SELECTED EMPLOYEE
  // =====================================================
  // Backend returns an array of employee calendar rows.
  // UI components expect a single employee object (or null).

  const overview = useMemo(() => {
    let base: any = null;

    if (!rawOverview) {
      base = null;
    } else if (Array.isArray(rawOverview)) {
      if (!selectedEmployee?.id) {
        base = rawOverview[0] ?? null;
      } else {
        const match = rawOverview.find(
          (row: { EmployeeID?: string | number }) =>
            String(row?.EmployeeID ?? "") ===
            String(selectedEmployee.id),
        );
        base = match ?? rawOverview[0] ?? null;
      }
    } else {
      base = rawOverview;
    }

    // Enrich with simple aggregates from normalized days when
    // the overview payload does not already carry totals.
    // This keeps Monthly Overview cards from staying at 0.00
    // when only the metric-style daily rows are present.
    if (base && days.length > 0) {
      const hasTotalHours =
        base.totalHours != null ||
        base.TotalHours != null ||
        base.total_hours != null ||
        base.totalWorkHours != null;

      if (!hasTotalHours) {
        // Sum workHours / grossWorkHours that look like HH:MM or numbers
        let totalMinutes = 0;
        for (const d of days) {
          const raw =
            d.workHours || d.grossWorkHours || "";
          if (!raw) continue;
          const str = String(raw).trim();
          if (str.includes(":")) {
            const [h, m] = str.split(":").map(Number);
            if (Number.isFinite(h) && Number.isFinite(m)) {
              totalMinutes += h * 60 + m;
            }
          } else {
            const n = Number(str);
            if (Number.isFinite(n)) totalMinutes += n * 60;
          }
        }
        const hrs = Math.floor(totalMinutes / 60);
        const mins = totalMinutes % 60;
        base = {
          ...base,
          totalHours: `${hrs}.${String(mins).padStart(2, "0")}`,
          TotalHours: `${hrs}.${String(mins).padStart(2, "0")}`,
        };
      }
    }

    return base;
  }, [rawOverview, selectedEmployee?.id, days]);

  // =====================================================
  // OVERVIEW STATS
  // =====================================================

  const overviewStats = useMemo(
    () =>
      getOverviewStats(
        overview,
        days,
      ),
    [overview, days],
  );

  // =====================================================
  // ACTIVE DAY
  // =====================================================

  const activeDay =
    days.find(
      (day) =>
        day.date === selectedDate,
    ) ?? days[0];

  // =====================================================
  // KEEP SELECTED DATE VALID
  // =====================================================

  useEffect(() => {
    if (
      days.length > 0 &&
      !days.some(
        (day) =>
          day.date === selectedDate,
      )
    ) {
      setSelectedDate(days[0].date);
    }
  }, [
    days,
    selectedDate,
  ]);

  // =====================================================
  // TOAST
  // =====================================================

  const pushToast = useCallback(
    (
      message: string,
      tone: Toast["tone"] = "info",
    ) => {
      const id =
        Date.now() +
        Math.random();

      setToasts((current) => [
        ...current,
        {
          id,
          message,
          tone,
        },
      ]);

      window.setTimeout(() => {
        setToasts((current) =>
          current.filter(
            (item) =>
              item.id !== id,
          ),
        );
      }, 3200);
    },
    [],
  );

  // =====================================================
  // PROCESS ATTENDANCE
  // =====================================================
  // Temporary local UI behavior.
  // Replace with API mutation once processing API is provided.

  const handleProcessClick =
    useCallback(() => {
      if (!processed) {
        setProcessed(true);

        setProcessedAt(
          new Date().toLocaleString(),
        );

        pushToast(
          "Attendance processed successfully.",
          "success",
        );
      } else {
        setProcessMenuOpen(
          (value) => !value,
        );
      }
    }, [
      processed,
      pushToast,
    ]);

  // =====================================================
  // REPROCESS
  // =====================================================

  const handleReprocess =
    useCallback(() => {
      setProcessedAt(
        new Date().toLocaleString(),
      );

      setProcessMenuOpen(false);

      pushToast(
        "Attendance re-processed successfully.",
        "success",
      );
    }, [pushToast]);

  // =====================================================
  // UNDO PROCESS
  // =====================================================

  const handleUndoProcess =
    useCallback(() => {
      setProcessed(false);
      setProcessedAt(null);
      setProcessMenuOpen(false);

      pushToast(
        "Attendance processing undone.",
        "info",
      );
    }, [pushToast]);

  // =====================================================
  // EXPORT
  // =====================================================

  const handleExport =
    useCallback(() => {
      try {
        const header =
          "Date,Day,Shift,Status,Check In,Check Out,Gross Work Hours,Work Hours,Break Hours";

        const rows = days.map(
          (day) =>
            [
              day.date,
              day.day,
              day.shift,
              day.status,
              day.checkIn ?? "",
              day.checkOut ?? "",
              day.grossWorkHours ?? "",
              day.workHours ?? "",
              day.breakHours ?? "",
            ].join(","),
        );

        const csv = [
          header,
          ...rows,
        ].join("\n");

        const blob =
          new Blob([csv], {
            type: "text/csv;charset=utf-8;",
          });

        const url =
          URL.createObjectURL(
            blob,
          );

        const anchor =
          document.createElement(
            "a",
          );

        anchor.href = url;

        anchor.download =
          `attendance_${
            selectedEmployee?.id ?? ""
          }_${selectedMonth.replace(
            "/",
            "-",
          )}.csv`;

        document.body.appendChild(
          anchor,
        );

        anchor.click();

        document.body.removeChild(
          anchor,
        );

        window.setTimeout(() => {
          URL.revokeObjectURL(
            url,
          );
        }, 5000);

        pushToast(
          "Attendance exported successfully.",
          "success",
        );
      } catch (exportError) {
        console.error(
          "CSV export failed:",
          exportError,
        );

        pushToast(
          "Export failed.",
          "info",
        );
      }
    }, [
      days,
      pushToast,
      selectedEmployee?.id,
      selectedMonth,
    ]);

  // =====================================================
  // SELECT DATE
  // =====================================================

  const selectDate =
    useCallback(
      (date: number) => {
        setSelectedDate(date);
      },
      [],
    );

  // =====================================================
  // SELECT EMPLOYEE
  // =====================================================

  const selectEmployee =
    useCallback(
      (employee: Employee) => {
        setSelectedEmployee(
          employee,
        );

        setSelectedDate(
          currentDate.getDate(),
        );
      },
      [currentDate],
    );

  // =====================================================
  // DETAIL MODAL
  // =====================================================

  const openDetailModal =
    useCallback(
      (key: OverviewDetailKey) => {
        setActiveDetailModal(
          key,
        );
      },
      [],
    );

  const closeDetailModal =
    useCallback(() => {
      setActiveDetailModal(null);
    }, []);

  // =====================================================
  // LOAD SELECTED DAY PUNCHES
  // =====================================================

  const loadSelectedDayPunches =
    useCallback(
      async () => {
        if (!activeDay) {
          return;
        }

        const date =
          `${selectedYear}-${String(
            selectedMonthNumber,
          ).padStart(
            2,
            "0",
          )}-${String(
            activeDay.date,
          ).padStart(
            2,
            "0",
          )}`;

        try {
          await loadPunchDetails(
            date,
          );

          await loadRawPunches(
            date,
          );
        } catch (punchError) {
          console.error(
            "Failed to load punch details:",
            punchError,
          );
        }
      },
      [
        activeDay,
        selectedYear,
        selectedMonthNumber,
        loadPunchDetails,
        loadRawPunches,
      ],
    );

  // =====================================================
  // RETURN
  // =====================================================

  return {
    view,
    setView,

    selectedMonth,
    setSelectedMonth,

    employees:
      employeeOptions,

    selectedEmployee,
    selectEmployee,

    reportingEmployeesLoading,
    reportingEmployeesError,

    selectedMonthNumber,
    selectedYear,

    assignedShift,
    setAssignedShift,

    workedShift,
    setWorkedShift,

    assignedPolicy,
    setAssignedPolicy,

    assignedPattern,
    setAssignedPattern,

    selectedDate,
    setSelectedDate:
      selectDate,

    punchTab,
    setPunchTab,

    days,
    activeDay,

    overview,
    overviewStats,

    loading,
    error,

    toasts,
    setToasts,
    pushToast,

    processed,
    processedAt,

    processMenuOpen,
    setProcessMenuOpen,

    activeDetailModal,
    openDetailModal,
    closeDetailModal,

    handleProcessClick,
    handleReprocess,
    handleUndoProcess,
    handleExport,

    loadSelectedDayPunches,

    rawPunches,
  };
}