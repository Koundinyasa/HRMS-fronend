/** Request parameters sent to the pending leave requests API. */
export interface PendingLeaveRequestParams {
  fromDate: string;
  toDate: string;
}

/** Raw leave-request record returned by the backend API. */
export interface PendingLeaveRequest {
  ApprovalId?: string | number;
  ApprovalID?: string | number;
  LeaveId?: string | number;
  LeaveID?: string | number;
  Id?: string | number;
  EmployeeId?: string | number;
  EmployeeName?: string;
  LeaveName?: string;
  FromDate?: string;
  ToDate?: string;
  NoDays?: number | string;
  NoOfDays?: number | string;
  AppliedDate?: string;
  Reason?: string | null;
}

/** Fields used by the requisition UI. */
export interface Requisition {
  id: string;
  approvalId: number;
  leaveId: number;
  employeeId: string;
  employeeName: string;
  leaveName: string;
  date: string;
  days: number;
  reason: string;
}

/** Props for the requisition table. */
export interface RequisitionTableProps {
  requisitions: Requisition[];
  selectedIds: string[];
  onSelectAll: () => void;
  onSelect: (id: string) => void;
}

/** Props for the requisition toolbar. */
export interface RequisitionToolbarProps {
  search: string;
  onSearchChange: (value: string) => void;
  onApprove: () => void;
  onReject: () => void;
  onHistory: () => void;
  hasSelection: boolean;
  approved?: boolean;
}

/** Result returned by requisition date validation. */
export interface RequisitionValidationResult {
  isValid: boolean;
  message: string;
}

export type PendingLeaveRequestsResponse =
  PendingLeaveRequest[];