import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Plus, Search, History } from "lucide-react";
import ClassificationNavbar from "../components/ClassificationNavbar";
import DesignationList from "../components/DesignationList";
import TablePaginationFooter from "../components/TablePaginationFooter";
import { useDesignation } from "../hooks/useDesignation";
import { useMemo, useState } from "react";

export default function DesignationPage() {
  const {
    designations, total, page, pageSize, setPageSize, isLoading, setPage,
    isFormOpen, openAdd, openEdit, closeForm,
    form, setDesignationName, submit, isSaving,
    deleteTarget, setDeleteTarget, confirmDelete, isDeleting,
  } = useDesignation();

  const [search, setSearch] = useState("");

  // The designations API paginates server-side, so search only filters the
  // page currently loaded. Add a `search` query param on the backend to
  // search across all designations instead of just the visible page.
  const visibleDesignations = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q ? designations.filter((d) => d.DesignationName.toLowerCase().includes(q)) : designations;
  }, [designations, search]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const rangeStart = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const rangeEnd = Math.min(page * pageSize, total);

  return (
    <div className="w-full">
      <ClassificationNavbar
        rightSlot={
          <>
            <div className="relative w-full sm:w-auto">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search..."
                className="h-9 w-full sm:w-48 rounded-lg border border-gray-200 bg-white pl-9 pr-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
              />
            </div>
            <button
              type="button"
              onClick={openAdd}
              className="flex items-center gap-1.5 bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap"
            >
              <Plus size={16} /> Add New
            </button>
            <button
              type="button"
              aria-label="History"
              className="w-9 h-9 rounded-full border flex items-center justify-center text-gray-400 hover:text-gray-600"
            >
              <History size={16} />
            </button>
          </>
        }
      />

      <div className="mt-4 px-6 pb-8">
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          {isFormOpen && (
            <div className="mx-4 mt-4 mb-2 rounded-xl border p-6 space-y-4 bg-muted/30">
              <div className="space-y-2">
                <Label htmlFor="designation-name">Designation Name</Label>
                <Input
                  id="designation-name"
                  value={form.designationName}
                  onChange={(e) => setDesignationName(e.target.value)}
                  placeholder="e.g. HR Executive"
                />
              </div>
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={closeForm}>Cancel</Button>
                <Button onClick={submit} disabled={isSaving} className="bg-violet-600 hover:bg-violet-700 text-white">
                  {isSaving ? "Saving..." : "Save"}
                </Button>
              </div>
            </div>
          )}

          {deleteTarget && (
            <div className="mx-4 mt-4 mb-2 rounded-xl border border-red-200 bg-red-50 p-4 flex items-center justify-between">
              <p className="text-sm text-red-700">Delete <strong>{deleteTarget.DesignationName}</strong>?</p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setDeleteTarget(null)}>Cancel</Button>
                <Button size="sm" onClick={confirmDelete} disabled={isDeleting} className="bg-red-600 hover:bg-red-700 text-white">
                  {isDeleting ? "Deleting..." : "Delete"}
                </Button>
              </div>
            </div>
          )}

          {isLoading ? (
            <p className="text-sm text-muted-foreground py-8 text-center">Loading designations...</p>
          ) : (
            <>
              <div className="overflow-x-auto">
                <DesignationList designations={visibleDesignations} onEdit={openEdit} onDelete={setDeleteTarget} />
              </div>

              <TablePaginationFooter
                rowsPerPage={pageSize}
                onRowsPerPageChange={setPageSize}
                page={page}
                totalPages={totalPages}
                onPageChange={setPage}
                rangeStart={rangeStart}
                rangeEnd={rangeEnd}
                totalCount={total}
              />
            </>
          )}
        </div>
      </div>
    </div>
  );
}
