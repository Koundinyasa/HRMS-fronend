import { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Plus, Search, History } from "lucide-react";
import ClassificationNavbar from "../components/ClassificationNavbar";
import BankList, { type BankSortKey } from "../components/BankList";
import TablePaginationFooter from "../components/TablePaginationFooter";
import { useBanks } from "../hooks/useBanks";
import type { Bank } from "../types/classificationTypes";

export default function BanksPage() {
  const navigate = useNavigate();
  const { domain } = useParams();
  const {
    banks, isLoading, usingFallback,
    isFormOpen, openAdd, openEdit, closeForm,
    form, setField, submit, isSaving,
    deleteTarget, setDeleteTarget, confirmDelete, isDeleting,
  } = useBanks();

  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState<BankSortKey | null>(null);
  const [sortAsc, setSortAsc] = useState(true);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(1);

  const openFieldMapping = (bank: Bank) =>
    navigate(`/${domain}/admin/admin-center/classifications/banks/${bank.Id}/field-mapping`);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const base = q
      ? banks.filter(
          (b) =>
            b.BankName.toLowerCase().includes(q) ||
            b.AcType.toLowerCase().includes(q) ||
            b.IfscCode.toLowerCase().includes(q)
        )
      : banks;

    if (!sortKey) return base;
    const sorted = [...base].sort((a: Bank, b: Bank) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      if (av === bv) return 0;
      return av > bv ? 1 : -1;
    });
    return sortAsc ? sorted : sorted.reverse();
  }, [banks, search, sortKey, sortAsc]);

  const totalCount = filtered.length;
  const totalPages = Math.max(1, Math.ceil(totalCount / rowsPerPage));
  const currentPage = Math.min(page, totalPages);
  const pageRows = filtered.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);
  const rangeStart = totalCount === 0 ? 0 : (currentPage - 1) * rowsPerPage + 1;
  const rangeEnd = Math.min(currentPage * rowsPerPage, totalCount);

  const handleSort = (key: BankSortKey) => {
    if (sortKey === key) {
      setSortAsc((prev) => !prev);
    } else {
      setSortKey(key);
      setSortAsc(true);
    }
  };

  return (
    <div className="w-full">
      <ClassificationNavbar
        rightSlot={
          <>
            <div className="relative w-full sm:w-auto">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
                placeholder="Search..."
                className="h-9 w-full sm:w-48 rounded-lg border border-gray-200 bg-white pl-9 pr-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
              />
            </div>
            <button
              type="button"
              onClick={openAdd}
              className="flex items-center gap-1.5 bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap"
            >
              <Plus size={16} /> Add New
            </button>
            <button
              type="button"
              aria-label="History"
              className="w-9 h-9 rounded-full border flex items-center justify-center text-gray-400 hover:text-gray-600"
            >
              <History size={16} />
            </button>
          </>
        }
      />

      <p className="px-6 mt-4 text-xs text-gray-400">Classifications / Bank</p>

      {usingFallback && (
        <div className="mx-6 mt-3 rounded-lg border border-amber-200 bg-amber-50 px-4 py-2 text-xs text-amber-700">
          Showing preview data — the banks API isn't live on the backend yet, so this list isn't connected to
          real data and edits won't be saved.
        </div>
      )}

      <div className="mt-4 px-6 pb-8">
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          {isFormOpen && (
            <div className="mx-4 mt-4 mb-4 rounded-xl border p-6 space-y-4 bg-muted/30">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="bank-name">Bank Name</Label>
                  <Input id="bank-name" value={form.bankName} onChange={(e) => setField("bankName", e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bank-actype">Account Type</Label>
                  <Input id="bank-actype" value={form.acType} onChange={(e) => setField("acType", e.target.value)} placeholder="e.g. Salary Account" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bank-ifsc">IFSC Code</Label>
                  <Input id="bank-ifsc" value={form.ifscCode} onChange={(e) => setField("ifscCode", e.target.value.toUpperCase())} placeholder="e.g. IBKL0000002" />
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={closeForm}>Cancel</Button>
                <Button onClick={submit} disabled={isSaving} className="bg-violet-600 hover:bg-violet-700 text-white">
                  {isSaving ? "Saving..." : "Save"}
                </Button>
              </div>
            </div>
          )}

          {deleteTarget && (
            <div className="mx-4 mb-4 rounded-xl border border-red-200 bg-red-50 p-4 flex items-center justify-between">
              <p className="text-sm text-red-700">Delete <strong>{deleteTarget.BankName}</strong>? This cannot be undone.</p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setDeleteTarget(null)}>Cancel</Button>
                <Button size="sm" onClick={confirmDelete} disabled={isDeleting} className="bg-red-600 hover:bg-red-700 text-white">
                  {isDeleting ? "Deleting..." : "Delete"}
                </Button>
              </div>
            </div>
          )}

          {isLoading ? (
            <p className="text-sm text-muted-foreground py-8 text-center">Loading banks...</p>
          ) : (
            <>
              <div className="overflow-x-auto">
                <BankList
                  banks={pageRows}
                  onEdit={openEdit}
                  onDelete={setDeleteTarget}
                  onConfigure={openFieldMapping}
                  sortKey={sortKey}
                  onSort={handleSort}
                />
              </div>

              <TablePaginationFooter
                rowsPerPage={rowsPerPage}
                onRowsPerPageChange={(n) => {
                  setRowsPerPage(n);
                  setPage(1);
                }}
                page={currentPage}
                totalPages={totalPages}
                onPageChange={setPage}
                rangeStart={rangeStart}
                rangeEnd={rangeEnd}
                totalCount={totalCount}
              />
            </>
          )}
        </div>
      </div>
    </div>
  );
}
