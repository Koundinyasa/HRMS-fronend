import { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { UploadCloud, CheckCircle2 } from "lucide-react";
import ClassificationNavbar from "../components/ClassificationNavbar";
import { useImport } from "../hooks/useImport";

export default function ImportPage() {
  const {
    templateType, setTemplateType, templateTypes,
    file, setFile,
    downloadTemplate, isDownloading,
    upload, isUploading,
  } = useImport();

  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <div className="w-full">
      <ClassificationNavbar />

      <div className="mt-8 px-8">
        <Card className="mx-auto max-w-3xl rounded-2xl border shadow-sm">
          <CardHeader className="px-8 pt-8">
            <CardTitle className="text-2xl font-bold">Import</CardTitle>
            <CardDescription className="text-base">Bulk import Branch, Designation, or Bank details.</CardDescription>
          </CardHeader>

          <CardContent className="px-8 pb-8 space-y-6">
            <div className="space-y-2">
              <Label htmlFor="template-type">Template Type</Label>
              <select
                id="template-type"
                value={templateType}
                onChange={(e) => setTemplateType(e.target.value as typeof templateType)}
                className="h-11 w-64 rounded-lg border border-input bg-background px-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500"
              >
                {templateTypes.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>

            <div className="flex gap-6">
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => { e.preventDefault(); if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]); }}
                className="flex-1 border-2 border-dashed border-blue-200 rounded-xl flex flex-col items-center justify-center py-14 bg-blue-50/40"
              >
                <UploadCloud size={36} className="text-blue-600 mb-3" />
                <p className="text-sm text-muted-foreground">
                  Drag & drop <br />
                  Or{" "}
                  <button onClick={() => inputRef.current?.click()} className="text-blue-600 font-medium underline">
                    Browse
                  </button>
                </p>
                <input ref={inputRef} type="file" className="hidden" accept=".xlsx,.xls,.csv" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
                {file && <p className="mt-3 text-xs text-muted-foreground">{file.name}</p>}
              </div>

              <div className="w-64 bg-muted rounded-xl p-4">
                <h4 className="text-sm font-semibold mb-3">File Requirement</h4>
                <p className="flex items-center gap-2 text-xs text-emerald-600">
                  <CheckCircle2 size={14} /> The Selected File Should Be Valid
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <Button onClick={downloadTemplate} disabled={isDownloading} className="bg-blue-600 hover:bg-blue-700 text-white">
                {isDownloading ? "Downloading..." : "Template"}
              </Button>
              <Button onClick={upload} disabled={!file || isUploading} className="bg-blue-600 hover:bg-blue-700 text-white">
                <UploadCloud size={16} className="mr-2" /> {isUploading ? "Uploading..." : "Upload File"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
