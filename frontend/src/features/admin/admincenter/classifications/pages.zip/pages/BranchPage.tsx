import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Plus, Search, History } from "lucide-react";
import ClassificationNavbar from "../components/ClassificationNavbar";
import BranchList, { type BranchSortKey } from "../components/BranchList";
import TableViewToolbar from "../components/TableViewToolbar";
import TablePaginationFooter from "../components/TablePaginationFooter";
import { useBranch } from "../hooks/useBranch";
import type { Branch } from "../types/classificationTypes";

const STATES = ["Telangana", "Andhra Pradesh", "Karnataka", "Tamil Nadu", "Maharashtra", "Delhi"];

export default function BranchPage() {
  const {
    branches, isLoading,
    isFormOpen, openAdd, openEdit, closeForm,
    form, setField, setActive, submit, isSaving,
    deleteTarget, setDeleteTarget, confirmDelete, isDeleting,
  } = useBranch();

  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState<BranchSortKey | null>(null);
  const [sortAsc, setSortAsc] = useState(true);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const base = q
      ? branches.filter(
          (b) =>
            b.BranchName.toLowerCase().includes(q) ||
            b.Address.toLowerCase().includes(q) ||
            b.State.toLowerCase().includes(q)
        )
      : branches;

    if (!sortKey) return base;
    const sorted = [...base].sort((a: Branch, b: Branch) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      if (av === bv) return 0;
      return av > bv ? 1 : -1;
    });
    return sortAsc ? sorted : sorted.reverse();
  }, [branches, search, sortKey, sortAsc]);

  const totalCount = filtered.length;
  const totalPages = Math.max(1, Math.ceil(totalCount / rowsPerPage));
  const currentPage = Math.min(page, totalPages);
  const pageRows = filtered.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);
  const rangeStart = totalCount === 0 ? 0 : (currentPage - 1) * rowsPerPage + 1;
  const rangeEnd = Math.min(currentPage * rowsPerPage, totalCount);

  const handleSort = (key: BranchSortKey) => {
    if (sortKey === key) {
      setSortAsc((prev) => !prev);
    } else {
      setSortKey(key);
      setSortAsc(true);
    }
  };

  return (
    <div className="w-full">
      <ClassificationNavbar
        rightSlot={
          <>
            <div className="relative w-full sm:w-auto">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
                placeholder="Search..."
                className="h-9 w-full sm:w-48 rounded-lg border border-gray-200 bg-white pl-9 pr-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
              />
            </div>
            <button
              type="button"
              onClick={openAdd}
              className="flex items-center gap-1.5 bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap"
            >
              <Plus size={16} /> Add New
            </button>
            <button
              type="button"
              aria-label="History"
              className="w-9 h-9 rounded-full border flex items-center justify-center text-gray-400 hover:text-gray-600"
            >
              <History size={16} />
            </button>
          </>
        }
      />

      <p className="px-6 mt-4 text-xs text-gray-400">Classifications / Branch</p>

      <div className="mt-4 px-6 pb-8">
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          {isFormOpen && (
            <div className="mx-4 mb-4 rounded-xl border p-6 space-y-4 bg-muted/30">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="branch-name">Branch Name</Label>
                  <Input id="branch-name" value={form.branchName} onChange={(e) => setField("branchName", e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="branch-state">State</Label>
                  <select
                    id="branch-state"
                    value={form.state}
                    onChange={(e) => setField("state", e.target.value)}
                    className="h-9 w-full rounded-lg border border-input bg-transparent px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
                  >
                    <option value="">Select state</option>
                    {STATES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="branch-address">Address</Label>
                <Input id="branch-address" value={form.address} onChange={(e) => setField("address", e.target.value)} />
              </div>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={form.isActive === 1} onChange={(e) => setActive(e.target.checked ? 1 : 0)} />
                Active
              </label>
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={closeForm}>Cancel</Button>
                <Button onClick={submit} disabled={isSaving} className="bg-violet-600 hover:bg-violet-700 text-white">
                  {isSaving ? "Saving..." : "Save"}
                </Button>
              </div>
            </div>
          )}

          {deleteTarget && (
            <div className="mx-4 mb-4 rounded-xl border border-red-200 bg-red-50 p-4 flex items-center justify-between">
              <p className="text-sm text-red-700">Delete <strong>{deleteTarget.BranchName}</strong>? This cannot be undone.</p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setDeleteTarget(null)}>Cancel</Button>
                <Button size="sm" onClick={confirmDelete} disabled={isDeleting} className="bg-red-600 hover:bg-red-700 text-white">
                  {isDeleting ? "Deleting..." : "Delete"}
                </Button>
              </div>
            </div>
          )}

          {isLoading ? (
            <p className="text-sm text-muted-foreground py-8 text-center">Loading branches...</p>
          ) : (
            <>
              <div className="overflow-x-auto">
                <BranchList
                  branches={pageRows}
                  onEdit={openEdit}
                  onDelete={setDeleteTarget}
                  sortKey={sortKey}
                  onSort={handleSort}
                />
              </div>

              <TableViewToolbar />

              <TablePaginationFooter
                rowsPerPage={rowsPerPage}
                onRowsPerPageChange={(n) => {
                  setRowsPerPage(n);
                  setPage(1);
                }}
                page={currentPage}
                totalPages={totalPages}
                onPageChange={setPage}
                rangeStart={rangeStart}
                rangeEnd={rangeEnd}
                totalCount={totalCount}
              />
            </>
          )}
        </div>
      </div>
    </div>
  );
}
