import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Plus, Search, History, Settings2, Network, ChevronLeft, ChevronRight, ChevronsLeft } from "lucide-react";
import ClassificationNavbar from "../components/ClassificationNavbar";
import SalaryComponentList from "../components/SalaryComponentList";
import SalaryStructureTable from "../components/SalaryStructureTable";
import SalaryStructureEntryModal from "../components/SalaryStructureEntryModal";
import SalaryStructureSidebar from "../components/SalaryStructureSidebar";
import { SalaryStructureDefModal, SalaryStructureDeleteModal } from "../components/SalaryStructureDefModal";
import { useSalaryComponent } from "../hooks/useSalaryComponent";
import { useSalaryStructure } from "../hooks/useSalaryStructure";
import { useSalaryStructureDefinitions } from "../hooks/useSalaryStructureDefinitions";

const ROWS_PER_PAGE_OPTIONS = [25, 50, 100];

export default function SalaryStructurePage() {
  const {
    components, allComponents, isLoading, usingFallback,
    activeTab, setActiveTab,
    search, setSearch,
    isFormOpen, openAdd, openEdit, closeForm,
    form, setField, setCalculative, setOpenComponent, submit, isSaving,
    deleteTarget, setDeleteTarget, confirmDelete, isDeleting,
    createFromDefaults, isCreatingDefaults,
  } = useSalaryComponent();

  const {
    structures,
    selectedId: selectedStructureId,
    setSelectedId: setSelectedStructureId,
    selectedStructure,
    editingStructure, setEditingStructure, isAdding,
    openAdd: openAddStructure, openEdit: openEditStructure, closeEdit: closeEditStructure, saveEdit: saveEditStructure,
    deleteTarget: deleteStructureTarget, setDeleteTarget: setDeleteStructureTarget, confirmDelete: confirmDeleteStructure,
    cloneStructure,
  } = useSalaryStructureDefinitions();

  const {
    structureTab, setStructureTab,
    showTillDate, setShowTillDate,
    earningsCount, deductionsCount,
    rows: structureRows, setOrder,
    editingEntry, setEditingEntry, openEditEntry, closeEditEntry, saveEditEntry,
  } = useSalaryStructure(allComponents, selectedStructureId);

  const [innerTab, setInnerTab] = useState<"components" | "structure">("components");
  const [rowsPerPage, setRowsPerPage] = useState(100);
  const [page, setPage] = useState(1);

  const total = components.length;
  const totalPages = Math.max(1, Math.ceil(total / rowsPerPage));
  const safePage = Math.min(page, totalPages);
  const pageRows = components.slice((safePage - 1) * rowsPerPage, safePage * rowsPerPage);

  const handleSearchChange = (value: string) => {
    setSearch(value);
    setPage(1);
  };

  const handleTabChange = (tab: "Earnings" | "Deduction") => {
    setActiveTab(tab);
    setPage(1);
  };

  return (
    <div className="w-full">
      <ClassificationNavbar />

      <p className="px-8 mt-4 text-xs text-gray-400">
        Master / {selectedStructure?.Name ?? "Structure"} / {innerTab === "structure" ? "Structure" : "Components"}
      </p>

      <div className="mt-4 px-8 flex gap-6 items-start">
        <SalaryStructureSidebar
          structures={structures}
          selectedId={selectedStructureId}
          onSelect={setSelectedStructureId}
          onAdd={openAddStructure}
          onEdit={openEditStructure}
          onDelete={setDeleteStructureTarget}
          onClone={cloneStructure}
        />

        <div className="flex-1 min-w-0">
        <Card className="rounded-2xl border shadow-sm">
          <CardContent className="p-6">
            {/* Components / Structure tabs */}
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2 bg-gray-50 rounded-xl p-1 border">
                <button
                  type="button"
                  onClick={() => setInnerTab("components")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    innerTab === "components" ? "bg-white shadow-sm text-violet-600" : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <Settings2 size={15} /> Components
                </button>
                <button
                  type="button"
                  onClick={() => setInnerTab("structure")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    innerTab === "structure" ? "bg-white shadow-sm text-violet-600" : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <Network size={15} /> Structure
                </button>
              </div>

              <div className="flex items-center gap-3">
                {innerTab === "structure" && (
                  <Button variant="outline" className="border-violet-200 text-violet-600 hover:bg-violet-50">
                    <ChevronsLeft size={16} className="mr-2" /> More Tabs
                  </Button>
                )}
                <Button
                  onClick={innerTab === "components" ? openAdd : undefined}
                  className="bg-violet-600 hover:bg-violet-700 text-white"
                >
                  <Plus size={16} className="mr-2" /> Component
                </Button>
                <button
                  type="button"
                  aria-label="History"
                  className="w-9 h-9 rounded-full border flex items-center justify-center text-gray-400 hover:text-gray-600"
                >
                  <History size={16} />
                </button>
              </div>
            </div>

            {innerTab === "structure" ? (
              <div className="rounded-xl border p-5">
                <div className="flex items-center justify-between mb-4 flex-wrap gap-4">
                  <div className="flex items-center gap-6 text-sm">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="structure-type"
                        checked={structureTab === "Earnings"}
                        onChange={() => setStructureTab("Earnings")}
                        className="accent-violet-600"
                      />
                      Earnings
                      <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-600">
                        {earningsCount}
                      </span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="structure-type"
                        checked={structureTab === "Deduction"}
                        onChange={() => setStructureTab("Deduction")}
                        className="accent-violet-600"
                      />
                      Deductions
                      <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-500">
                        {deductionsCount}
                      </span>
                    </label>
                  </div>

                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <span className="w-2 h-2 rounded-full bg-violet-600 inline-block" />
                    Calculation
                  </div>

                  <select
                    value={showTillDate}
                    onChange={(e) => setShowTillDate(e.target.value as "Show Till Date" | "Show All")}
                    className="h-9 rounded-lg border border-input bg-transparent px-3 text-sm outline-none"
                  >
                    <option value="Show Till Date">Show Till Date</option>
                    <option value="Show All">Show All</option>
                  </select>
                </div>

                {isLoading ? (
                  <p className="text-sm text-muted-foreground py-8 text-center">Loading structure...</p>
                ) : (
                  <SalaryStructureTable
                    rows={structureRows}
                    emptyLabel={structureTab === "Earnings" ? "Earnings" : "Deductions"}
                    onOrderChange={setOrder}
                    onEdit={(component) => {
                      const found = structureRows.find((r) => r.component.Id === component.Id);
                      openEditEntry(component, found ? found.entry.Order : structureRows.length + 1);
                    }}
                    onHistory={() => { /* history view not yet wired to a backend endpoint */ }}
                    onAdd={(component) => {
                      const found = structureRows.find((r) => r.component.Id === component.Id);
                      openEditEntry(component, found ? found.entry.Order : structureRows.length + 1);
                    }}
                  />
                )}
              </div>
            ) : (
              <>
                {usingFallback && (
                  <div className="mb-4 rounded-lg border border-amber-200 bg-amber-50 px-4 py-2 text-xs text-amber-700">
                    Showing preview data — the salary components API isn't live on the backend yet, so this list
                    isn't connected to real data and edits won't be saved.
                  </div>
                )}

                {/* Inline add/edit form */}
                {isFormOpen && (
                  <div className="mb-6 rounded-xl border p-6 space-y-4 bg-muted/30">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="component-name">Component Name</Label>
                        <Input
                          id="component-name"
                          value={form.componentName}
                          onChange={(e) => setField("componentName", e.target.value)}
                          placeholder="e.g. Special Allowance"
                          maxLength={50}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="component-print-name">Print Name</Label>
                        <Input
                          id="component-print-name"
                          value={form.printName}
                          onChange={(e) => setField("printName", e.target.value)}
                          placeholder="e.g. Special Allow"
                          maxLength={20}
                        />
                        <p className="text-xs text-muted-foreground">Shown on payslips. Max 20 characters.</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-8">
                      <label className="flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={form.isCalculative === 1}
                          onChange={(e) => setCalculative(e.target.checked ? 1 : 0)}
                        />
                        Calculative Field
                      </label>
                      <label className="flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={form.isOpenComponent === 1}
                          onChange={(e) => setOpenComponent(e.target.checked ? 1 : 0)}
                        />
                        Open Component
                      </label>
                    </div>
                    <div className="flex justify-end gap-3">
                      <Button variant="outline" onClick={closeForm}>Cancel</Button>
                      <Button onClick={submit} disabled={isSaving} className="bg-violet-600 hover:bg-violet-700 text-white">
                        {isSaving ? "Saving..." : "Save"}
                      </Button>
                    </div>
                  </div>
                )}

                {deleteTarget && (
                  <div className="mb-6 rounded-xl border border-red-200 bg-red-50 p-4 flex items-center justify-between">
                    <p className="text-sm text-red-700">
                      Delete <strong>{deleteTarget.ComponentName}</strong>? This cannot be undone.
                    </p>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => setDeleteTarget(null)}>Cancel</Button>
                      <Button size="sm" onClick={confirmDelete} disabled={isDeleting} className="bg-red-600 hover:bg-red-700 text-white">
                        {isDeleting ? "Deleting..." : "Delete"}
                      </Button>
                    </div>
                  </div>
                )}

                {/* Search + Earnings/Deduction toggle */}
                <div className="flex items-center justify-between mb-4 gap-4 flex-wrap">
                  <div className="relative w-64">
                    <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      value={search}
                      onChange={(e) => handleSearchChange(e.target.value)}
                      placeholder="Start Typing..."
                      className="w-full h-9 rounded-lg border border-input bg-transparent pl-9 pr-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
                    />
                  </div>

                  <div className="flex items-center gap-6">
                    <button
                      type="button"
                      onClick={createFromDefaults}
                      disabled={isCreatingDefaults}
                      className="text-sm font-medium text-violet-600 hover:text-violet-700 disabled:opacity-50"
                    >
                      {isCreatingDefaults ? "Adding..." : "Create from default components"}
                    </button>

                    <div className="flex items-center gap-4 text-sm">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="component-type"
                          checked={activeTab === "Earnings"}
                          onChange={() => handleTabChange("Earnings")}
                          className="accent-emerald-500"
                        />
                        Earnings
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="component-type"
                          checked={activeTab === "Deduction"}
                          onChange={() => handleTabChange("Deduction")}
                          className="accent-gray-400"
                        />
                        Deduction
                      </label>
                    </div>
                  </div>
                </div>

                {isLoading ? (
                  <p className="text-sm text-muted-foreground py-8 text-center">Loading components...</p>
                ) : (
                  <SalaryComponentList components={pageRows} onEdit={openEdit} onDelete={setDeleteTarget} />
                )}

                {/* Pagination footer */}
                <div className="flex items-center justify-end gap-6 mt-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <span>Rows per page</span>
                    <select
                      value={rowsPerPage}
                      onChange={(e) => {
                        setRowsPerPage(Number(e.target.value));
                        setPage(1);
                      }}
                      className="h-8 rounded-md border border-input bg-transparent px-2 text-sm outline-none"
                    >
                      {ROWS_PER_PAGE_OPTIONS.map((n) => (
                        <option key={n} value={n}>{n}</option>
                      ))}
                    </select>
                  </div>
                  <span>
                    {total === 0 ? "0 of 0" : `${(safePage - 1) * rowsPerPage + 1} to ${(safePage - 1) * rowsPerPage + pageRows.length} of ${total}`}
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      disabled={safePage <= 1}
                      onClick={() => setPage(safePage - 1)}
                      className="w-7 h-7 flex items-center justify-center rounded-md disabled:opacity-30 hover:bg-gray-100"
                      aria-label="Previous page"
                    >
                      <ChevronLeft size={16} />
                    </button>
                    <span className="w-7 h-7 flex items-center justify-center rounded-md bg-violet-600 text-white font-medium text-xs">
                      {safePage}
                    </span>
                    <button
                      type="button"
                      disabled={safePage >= totalPages}
                      onClick={() => setPage(safePage + 1)}
                      className="w-7 h-7 flex items-center justify-center rounded-md disabled:opacity-30 hover:bg-gray-100"
                      aria-label="Next page"
                    >
                      <ChevronRight size={16} />
                    </button>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
        </div>
      </div>

      {editingEntry && (
        <SalaryStructureEntryModal
          entry={editingEntry}
          componentName={
            allComponents.find((c) => c.Id === editingEntry.ComponentId)?.ComponentName ?? "Component"
          }
          onChange={setEditingEntry}
          onClose={closeEditEntry}
          onSave={saveEditEntry}
        />
      )}

      {editingStructure && (
        <SalaryStructureDefModal
          structure={editingStructure}
          isAdding={isAdding}
          onChange={setEditingStructure}
          onClose={closeEditStructure}
          onSave={saveEditStructure}
        />
      )}

      {deleteStructureTarget && (
        <SalaryStructureDeleteModal
          structure={deleteStructureTarget}
          onCancel={() => setDeleteStructureTarget(null)}
          onConfirm={confirmDeleteStructure}
        />
      )}
    </div>
  );
}
