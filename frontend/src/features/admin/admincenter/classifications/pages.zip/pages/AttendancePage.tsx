import { Search, Plus, History } from "lucide-react";
import ClassificationNavbar from "../components/ClassificationNavbar";
import AttendanceConfigTable from "../components/AttendanceConfigTable";
import TablePaginationFooter from "../components/TablePaginationFooter";
import { AttendanceConfigModal, AttendanceConfigDeleteModal } from "../components/AttendanceConfigModal";
import { useAttendanceConfig } from "../hooks/useAttendanceConfig";

export default function AttendancePage() {
  const {
    search, setSearch,
    rowsPerPage, setRowsPerPage,
    page, totalPages, rangeStart, rangeEnd, totalCount, pageRows, setPage,
    toggleActive,
    editingConfig, setEditingConfig, isAdding, openAdd, openEdit, closeEdit, saveEdit,
    deleteTarget, setDeleteTarget, confirmDelete,
  } = useAttendanceConfig();

  return (
    <div className="w-full">
      <ClassificationNavbar />

      <p className="px-6 mt-4 text-xs text-gray-400">Attendance / Configurations / Configuration</p>

      <div className="mt-4 px-6 pb-8">
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <div className="flex items-center justify-between flex-wrap gap-3 p-4">
            <span className="px-5 py-2.5 rounded-lg text-sm font-medium bg-violet-600 text-white">
              Configuration
            </span>

            <div className="flex items-center gap-3 flex-wrap">
              <div className="relative w-full sm:w-auto">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search..."
                  className="h-9 w-full sm:w-56 rounded-lg border border-gray-200 bg-[#F5F3FF] pl-9 pr-3 text-sm outline-none"
                />
              </div>
              <button
                type="button"
                onClick={openAdd}
                className="flex items-center gap-1.5 bg-violet-600 hover:bg-violet-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap"
              >
                <Plus size={16} /> Add Attendance
              </button>
              <button
                type="button"
                aria-label="History"
                className="w-9 h-9 rounded-full border flex items-center justify-center text-gray-400 hover:text-gray-600"
              >
                <History size={16} />
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <AttendanceConfigTable
              rows={pageRows}
              onToggleActive={toggleActive}
              onEdit={openEdit}
              onDelete={setDeleteTarget}
            />
          </div>

          <TablePaginationFooter
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={setRowsPerPage}
            page={page}
            totalPages={totalPages}
            onPageChange={setPage}
            rangeStart={rangeStart}
            rangeEnd={rangeEnd}
            totalCount={totalCount}
          />
        </div>
      </div>

      {editingConfig && (
        <AttendanceConfigModal
          config={editingConfig}
          isAdding={isAdding}
          onChange={setEditingConfig}
          onClose={closeEdit}
          onSave={saveEdit}
        />
      )}

      {deleteTarget && (
        <AttendanceConfigDeleteModal
          config={deleteTarget}
          onCancel={() => setDeleteTarget(null)}
          onConfirm={confirmDelete}
        />
      )}
    </div>
  );
}
