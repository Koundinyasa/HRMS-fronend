import { useEffect, useState } from "react";
import DatePicker, {
  type DatePickerCell,
} from "@/components/ui/datepicker";
import type { DateFieldProps } from "../types/appliedLeave.types";

const toDisplay = (iso: string) => {
  if (!iso) return "";

  const [year, month, day] = iso.split("-");

  return `${day}-${month}-${year}`;
};

const maskDigits = (digits: string) => {
  const parts = [
    digits.slice(0, 2),
    digits.slice(2, 4),
    digits.slice(4, 8),
  ].filter(Boolean);

  return parts.join("-");
};

const digitsToIso = (digits: string) => {
  if (digits.length !== 8) return "";

  const day = Number(digits.slice(0, 2));
  const month = Number(digits.slice(2, 4));
  const year = Number(digits.slice(4, 8));

  const parsed = new Date(year, month - 1, day);

  const isRealDate =
    parsed.getFullYear() === year &&
    parsed.getMonth() === month - 1 &&
    parsed.getDate() === day;

  if (!isRealDate) return "";

  return `${digits.slice(4, 8)}-${digits.slice(2, 4)}-${digits.slice(0, 2)}`;
};

const isWithinRange = (
  iso: string,
  min?: string,
  max?: string,
) => {
  if (min && iso < min) return false;
  if (max && iso > max) return false;

  return true;
};

const isWeekendIso = (iso: string) => {
  const day = new Date(`${iso}T00:00:00`).getDay();

  return day === 0 || day === 6;
};

const WEEKDAY_LABELS = [
  "Su",
  "Mo",
  "Tu",
  "We",
  "Th",
  "Fr",
  "Sa",
];

const pad = (n: number) => `${n}`.padStart(2, "0");

const toIsoFromParts = (
  year: number,
  monthIndex: number,
  day: number,
) =>
  `${year}-${pad(monthIndex + 1)}-${pad(day)}`;

export default function DateField({
  id,
  value,
  min,
  max,
  onChange,
  disabled = false,
  align = "left",
  initialMonth,
}: DateFieldProps) {
  const [text, setText] = useState(
    () => toDisplay(value),
  );

  const [open, setOpen] = useState(false);

  const [viewDate, setViewDate] = useState(() => {
  const base = value
    ? new Date(`${value}T00:00:00`)
    : initialMonth
      ? new Date(`${initialMonth}T00:00:00`)
      : new Date();

  return new Date(
    base.getFullYear(),
    base.getMonth(),
    1,
  );
});

  useEffect(() => {
  setText(toDisplay(value));

  const base = value
    ? new Date(`${value}T00:00:00`)
    : initialMonth
      ? new Date(`${initialMonth}T00:00:00`)
      : new Date();

  setViewDate(
    new Date(
      base.getFullYear(),
      base.getMonth(),
      1,
    ),
  );
}, [value, initialMonth]);

  const isDisabled = (iso: string) => {
    if (!isWithinRange(iso, min, max)) {
      return true;
    }

    if (isWeekendIso(iso)) {
      return true;
    }

    return false;
  };

  const handleTextChange = (raw: string) => {
    if (disabled) return;

    const digits = raw
      .replace(/\D/g, "")
      .slice(0, 8);

    if (digits.length >= 2) {
      const day = Number(
        digits.slice(0, 2),
      );

      if (day < 1 || day > 31) {
        return;
      }
    }

    if (digits.length >= 4) {
      const month = Number(
        digits.slice(2, 4),
      );

      if (month < 1 || month > 12) {
        return;
      }
    }

    setText(maskDigits(digits));

    if (digits.length === 0) {
      onChange("");
      return;
    }

    const iso = digitsToIso(digits);

    if (!iso) {
      return;
    }

    if (isDisabled(iso)) {
      setText(toDisplay(value));
      return;
    }

    onChange(iso);
  };

  const handleBlur = () => {
    const digits = text.replace(/\D/g, "");

    if (digits.length === 0) {
      return;
    }

    const iso = digitsToIso(digits);

    if (!iso || isDisabled(iso)) {
      setText(toDisplay(value));
    }
  };

  const handleSelectDay = (iso: string) => {
    if (disabled || isDisabled(iso)) {
      return;
    }

    onChange(iso);
    setText(toDisplay(iso));
    setOpen(false);
  };

  const handleClear = () => {
    if (disabled) return;

    onChange("");
    setText("");
    setOpen(false);
  };

  const handleToday = () => {
    if (disabled) return;

    const today = new Date();

    const iso = toIsoFromParts(
      today.getFullYear(),
      today.getMonth(),
      today.getDate(),
    );

    if (isDisabled(iso)) {
      return;
    }

    setViewDate(
      new Date(
        today.getFullYear(),
        today.getMonth(),
        1,
      ),
    );

    handleSelectDay(iso);
  };

  const handlePrevMonth = () => {
    if (disabled) return;

    setViewDate(
      (date) =>
        new Date(
          date.getFullYear(),
          date.getMonth() - 1,
          1,
        ),
    );
  };

  const handleNextMonth = () => {
    if (disabled) return;

    setViewDate(
      (date) =>
        new Date(
          date.getFullYear(),
          date.getMonth() + 1,
          1,
        ),
    );
  };

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();

  const firstOfMonth = new Date(
    year,
    month,
    1,
  );

  const startOffset = firstOfMonth.getDay();

  const daysInMonth = new Date(
    year,
    month + 1,
    0,
  ).getDate();

  const daysInPrevMonth = new Date(
    year,
    month,
    0,
  ).getDate();

  const cells: DatePickerCell[] = [];

  // Previous month days
  for (
    let i = startOffset - 1;
    i >= 0;
    i--
  ) {
    const day = daysInPrevMonth - i;

    const prevMonthIndex =
      month === 0 ? 11 : month - 1;

    const prevYear =
      month === 0 ? year - 1 : year;

    const iso = toIsoFromParts(
      prevYear,
      prevMonthIndex,
      day,
    );

    cells.push({
      iso,
      day,
      inMonth: false,
      disabled: isDisabled(iso),
      selected: iso === value,
    });
  }

  // Current month days
  for (
    let day = 1;
    day <= daysInMonth;
    day++
  ) {
    const iso = toIsoFromParts(
      year,
      month,
      day,
    );

    cells.push({
      iso,
      day,
      inMonth: true,
      disabled: isDisabled(iso),
      selected: iso === value,
    });
  }

  // Next month days
  while (cells.length % 7 !== 0) {
    const last =
      cells[cells.length - 1];

    const nextDate = new Date(
      `${last.iso}T00:00:00`,
    );

    nextDate.setDate(
      nextDate.getDate() + 1,
    );

    const iso = toIsoFromParts(
      nextDate.getFullYear(),
      nextDate.getMonth(),
      nextDate.getDate(),
    );

    cells.push({
      iso,
      day: nextDate.getDate(),
      inMonth: false,
      disabled: isDisabled(iso),
      selected: iso === value,
    });
  }

  const monthLabel =
    viewDate.toLocaleDateString(
      "en-US",
      {
        month: "long",
        year: "numeric",
      },
    );

  return (
    <DatePicker
      id={id}
      text={text}
      onTextChange={handleTextChange}
      onBlur={handleBlur}
      isInvalid={false}
      open={open}
      onOpenChange={setOpen}
      monthLabel={monthLabel}
      weekdayLabels={WEEKDAY_LABELS}
      cells={cells}
      onSelectDay={handleSelectDay}
      onPrevMonth={handlePrevMonth}
      onNextMonth={handleNextMonth}
      onClear={handleClear}
      onToday={handleToday}
      align={align}
    />
  );
}